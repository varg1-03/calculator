<div id="placeholder" class="placeholder placeholder-empty">
    <div class="placeholder-icon">🧮</div>
    <h3 class="placeholder-title">Расчёт заработной платы</h3>
    <p class="placeholder-text">
        Введите номер магазина, количество часов<br>
        и выберите должность
    </p>
</div>

<div id="calculator" class="calculator">
    <h3> Расчет заработной платы</h3>
    <div class="results-container">
        <!-- Информация о магазине, должности и часах -->
        <div class="step">
            <div class="info-row">
                <span class="info-label">Магазин:</span>
                <span class="info-value" id="calcStoreNumber">-</span>
            </div>
            <div class="info-row">
                <span class="info-label">Должность:</span>
                <span class="info-value" id="calcPosition">-</span>
            </div>
            <div class="info-row">
                <span class="info-label">Часы:</span>
                <span class="info-value" id="calcHours">-</span>
            </div>
        </div>

        <!-- Часовая ставка -->
        <div class="step">
            <h4>Часовая ставка: <span id="baseRate">0 ₽</span></h4>
        </div>

        <!-- Оклад и премия отдельно -->
        <div class="salary-breakdown">
            <div class="step base-salary-block">
                <h4>Окладная часть:</h4>
                <div class="salary-value" id="salaryBase">0 ₽</div>
                <small class="salary-note">За отработанные часы</small>
            </div>

            <div class="step bonus-block" id="bonusBlock">
                <h4>Ежемесячная премия:</h4>
                <div class="salary-value" id="bonusAmount">0 ₽</div>
                <small class="salary-note" id="bonusDescription">-</small>
            </div>
        </div>

        <!-- Итоговая сумма с расшифровкой -->
        <div class="total-result">
            <div class="total-label">
                 ИТОГО (оклад + премия) 
            </div>
            <div class="total-value" id="finalSalary">0 ₽</div>
            <div class="total-breakdown" id="totalBreakdown">
                Оклад: 0 ₽ + Премия: 0 ₽
            </div>
        </div>

        <!-- Скрытый старый блок для обратной совместимости -->
        <div style="display: none;">
            <div class="step">
                <h4>Итого: <span id="hourlyTotal">0 ₽</span></h4>
            </div>
        </div>
    </div>
</div>